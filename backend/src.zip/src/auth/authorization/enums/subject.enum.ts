export enum Subject {
    //tài khoản
    User = 'User',
    
    //danh mục và sản phẩm
    Category = 'Category',
    Product = 'Product',
    ProductLine = 'ProductLine',
    Brand= 'Brand',

    //Mua hàng
    Cart = 'Cart',
    Address = 'Address',
    Order = 'Order',

    //Đánh giá
    Review = 'Review',

    //Khuyến mãi    
    Voucher = 'Voucher',
    VoucherUsage = 'VoucherUsage',
}