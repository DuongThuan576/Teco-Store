import { Module } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';

import { AppController } from './app.controller';
import { AppService } from './app.service';
import { ProductsModule } from './products/products.module';
import { MongooseModule } from '@nestjs/mongoose';
import { CategoriesModule } from './categories/categories.module';
import { BrandsModule } from './brands/brands.module';
import { ProductlinesModule } from './productlines/productlines.module';
import { AuthModule } from './auth/auth.module';
import { CartsModule } from './carts/carts.module';
import { AddressesModule } from './addresses/addresses.module';
import { UsersModule } from './users/users.module';
import { OrdersController } from './orders/orders.controller';
import { OrdersService } from './orders/orders.service';
import { OrdersModule } from './orders/orders.module';
import { ReviewsModule } from './reviews/reviews.module';
import { VouchersModule } from './vouchers/vouchers.module';
import { PaymentsModule } from './payments/payments.module';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
    }),

    MongooseModule.forRootAsync({
      imports: [ConfigModule],
      inject: [ConfigService],
      useFactory: (ConfigService: ConfigService) => ({
        uri: ConfigService.getOrThrow<string>('MONGODB_URI'),
        dbName: ConfigService.getOrThrow<string>('MONGODB_DATABASE'),
        autoIndex:true,
      }),
    }),

    ProductsModule,

    CategoriesModule,

    BrandsModule,

    ProductlinesModule,

    AuthModule,

    CartsModule,

    AddressesModule,

    UsersModule,

    OrdersModule,

    ReviewsModule,

    VouchersModule,

    PaymentsModule,
  ],

  controllers: [AppController],
  providers: [AppService],

})

export class AppModule { }
