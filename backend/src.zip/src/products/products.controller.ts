import { Body, Controller, Get, Param, BadRequestException, Post, Patch, Delete } from '@nestjs/common';
import { ProductsService } from './products.service';
import { CreateProductDTO } from './create-product.dto';
import { UpdateProductDTO } from './update-product.dto';
import { VariantDTO } from './variant.dto';
import { UpdateVariantDTO } from './update-variant.dto';

import { UseGuards } from '@nestjs/common';

import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { PoliciesGuard } from '../auth/authorization/policies/guards/policies.guard';
import { CheckPolicies } from '../auth/authorization/policies/decorators/check-policies.decorator';

import { Action } from '../auth/authorization/enums/action.enum';
import { Subject } from '../auth/authorization/enums/subject.enum';
@Controller('products')
export class ProductsController {
    constructor(
        private readonly productsService: ProductsService,
    ) { }

    //Lấy tất cả sản phẩm
    @Get()
    findAll() {
        return this.productsService.findAll();
    }

    //Tìm tất cả các variants của sp (admin)
    @Get(':productId/variants')
    findVariants(@Param('productId') productId: string) {
        return this.productsService.findVariants(productId);
    }

    // tìm theo slug (customer)
    @Get('slug/:slug')
    findBySlug(@Param('slug') slug: string) {
        return this.productsService.findBySlug(slug);
    }

    // tìm theo slug/sku (customer)
    @Get('slug/:slug/variants/:sku')
    findVariantBySku(
    @Param('slug') slug: string,
    @Param('sku') sku: string,
    ) {
    return this.productsService.findVariantBySku(
        slug,
        sku,
    );
    }

    // tìm theo id (admin)
    @Get(':id')
    findOne(@Param('id') id: string) {
        return this.productsService.findOne(id);
    }

    //Tìm variant theo id (admin)
    @Get(':productId/variants/:variantId')
    findVariantById(
        @Param('productId') productId: string,
        @Param('variantId') variantId: string,
        ) {
        return this.productsService.findVariantById(
            productId,
            variantId,
    );
}

    //Tạo sản phẩm mới (admin)
    @Post()
    @UseGuards(JwtAuthGuard, PoliciesGuard)
    @CheckPolicies({
        action: Action.Create,
        subject: Subject.Product,
    })
    create(@Body() createProductDTO: CreateProductDTO) {
        return this.productsService.create(createProductDTO);
    }

    //Thêm variant mới vào sản phẩm (admin)
    @Post(':productId/variants')
    @UseGuards(JwtAuthGuard, PoliciesGuard)
    @CheckPolicies({
        action: Action.Update,
        subject: Subject.Product,
    })
    addVariant(
        @Param('productId') productId: string,
        @Body() variantDTO: VariantDTO,
    ) {
        return this.productsService.addVariant(productId, variantDTO);
    }

    //update product (admin)
    @Patch(':id')
    @UseGuards(JwtAuthGuard, PoliciesGuard)
    @CheckPolicies({
        action: Action.Update,
        subject: Subject.Product,
    })
    update(
        @Param('id') id: string,
        @Body() updateProductDTO: UpdateProductDTO,
    ) {
        return this.productsService.update(id, updateProductDTO);
    }

    //route sửa variant( admin)
    @Patch(':productId/variants/:variantId')
    @UseGuards(JwtAuthGuard, PoliciesGuard)
    @CheckPolicies({
        action: Action.Update,
        subject: Subject.Product,
    })
    updateVariant(
        @Param('productId') productId: string,
        @Param('variantId') variantId: string,
        @Body() updateVariantDTO: UpdateVariantDTO
    ){
        return this.productsService.updateVariant(
            productId,
            variantId,
            updateVariantDTO,
        );
    }

    // route xóa variant (admin)
    @Delete(':productId/variants/:variantId')
    @UseGuards(JwtAuthGuard, PoliciesGuard)
    @CheckPolicies({
        action: Action.Delete,
        subject: Subject.Product,
    })
    removeVariant(
        @Param('productId') productId: string,
        @Param('variantId') variantId: string,
    ) {
        return this.productsService.removeVariant(
            productId,
            variantId,
        );
    }

    // xóa product (admin)
    @Delete(':id')
    @UseGuards(JwtAuthGuard, PoliciesGuard)
    @CheckPolicies({
        action: Action.Delete,
        subject: Subject.Product,
    })
    remove(@Param('id') id: string) {
        return this.productsService.remove(id);
    }

}
