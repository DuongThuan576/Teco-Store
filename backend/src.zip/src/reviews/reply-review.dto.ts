import {
  IsString,
  IsNotEmpty,
  MaxLength,
} from 'class-validator';

export class ReplyReviewDto {
  @IsString()
  @IsNotEmpty()
  @MaxLength(1000)
  comment: string;
}
